<?php
$moduleType = 'notices';
require __DIR__ . '/../config/module_manager.php';