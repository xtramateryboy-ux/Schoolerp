<?php
$moduleType = 'transport';
require __DIR__ . '/../config/module_manager.php';