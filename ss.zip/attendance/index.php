<?php
require __DIR__ . '/../config/auth.php';

$classes = $pdo->query(
    'SELECT DISTINCT class_name FROM students ORDER BY class_name'
)->fetchAll(PDO::FETCH_COLUMN);

$className = trim($_GET['class_name'] ?? '');
$section = trim($_GET['section'] ?? '');
$date = $_GET['date'] ?? date('Y-m-d');

$dateObject = DateTime::createFromFormat('Y-m-d', $date);

if (!$dateObject || $dateObject->format('Y-m-d') !== $date) {
    $date = date('Y-m-d');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $className = trim($_POST['class_name'] ?? '');
    $section = trim($_POST['section'] ?? '');
    $date = $_POST['date'] ?? '';

    $dateObject = DateTime::createFromFormat('Y-m-d', $date);

    if (
        $className === '' ||
        !$dateObject ||
        $dateObject->format('Y-m-d') !== $date
    ) {
        $error = 'Class aur valid date select karein.';
    } else {
        $statuses = $_POST['status'] ?? [];
        $validStatuses = ['Present', 'Absent', 'Late'];

        // Sirf wahi students process honge jo selected class/section mein hain.
        $studentStmt = $pdo->prepare(
            "SELECT id FROM students
             WHERE class_name = ?
               AND COALESCE(section, '') = ?"
        );
        $studentStmt->execute([$className, $section]);
        $studentIds = $studentStmt->fetchAll(PDO::FETCH_COLUMN);

        try {
            $pdo->beginTransaction();

            $saveStmt = $pdo->prepare(
                'INSERT INTO attendance
                    (student_id, attendance_date, status, marked_by)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    status = ?,
                    marked_by = ?'
            );

            foreach ($studentIds as $studentId) {
                $studentId = (int) $studentId;
                $status = $statuses[$studentId] ?? '';

                if (!in_array($status, $validStatuses, true)) {
                    continue;
                }

                $saveStmt->execute([
                    $studentId,
                    $date,
                    $status,
                    $_SESSION['user_id'],
                    $status,
                    $_SESSION['user_id']
                ]);
            }

            $pdo->commit();

            header(
                'Location: index.php?' . http_build_query([
                    'class_name' => $className,
                    'section' => $section,
                    'date' => $date,
                    'saved' => 1
                ])
            );
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $error = 'Attendance save nahi ho saki. Dobara try karein.';
        }
    }
}

$students = [];

if ($className !== '') {
    $stmt = $pdo->prepare(
        "SELECT
            s.id,
            s.admission_no,
            s.first_name,
            s.last_name,
            s.class_name,
            s.section,
            a.status
         FROM students s
         LEFT JOIN attendance a
            ON a.student_id = s.id
           AND a.attendance_date = ?
         WHERE s.class_name = ?
           AND COALESCE(s.section, '') = ?
         ORDER BY s.first_name, s.last_name"
    );

    $stmt->execute([$date, $className, $section]);
    $students = $stmt->fetchAll();
}

$saved = isset($_GET['saved']) && $_GET['saved'] === '1';
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <div class="user-area">
            <span><?= e($_SESSION['name']) ?></span>
            <a class="button button-outline" href="../logout.php">Logout</a>
        </div>
    </header>

    <main class="container">
        <div class="page-heading">
            <div>
                <p class="eyebrow">SCHOOL MANAGEMENT</p>
                <h1>Attendance</h1>
                <p class="muted">Class aur date ke hisaab se attendance mark karein.</p>
            </div>
        </div>

        <?php if ($saved): ?>
            <div class="success-message">Attendance successfully save ho gayi.</div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert"><?= e($error) ?></div>
        <?php endif; ?>

        <section class="table-card">
            <form method="GET" class="attendance-filter">
                <div>
                    <label for="class_name">Class</label>
                    <select id="class_name" name="class_name" required>
                        <option value="">Class select karein</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= e($class) ?>"
                                <?= $className === $class ? 'selected' : '' ?>>
                                <?= e($class) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="section">Section</label>
                    <input
                        id="section"
                        name="section"
                        value="<?= e($section) ?>"
                        placeholder="Jaise: A"
                    >
                </div>

                <div>
                    <label for="date">Date</label>
                    <input
                        id="date"
                        type="date"
                        name="date"
                        value="<?= e($date) ?>"
                        required
                    >
                </div>

                <button class="button button-primary filter-button" type="submit">
                    Show Students
                </button>
            </form>
        </section>

        <?php if ($className !== ''): ?>
            <section class="table-card attendance-card">
                <h2><?= e($className) ?><?= $section !== '' ? ' - Section ' . e($section) : '' ?></h2>
                <p class="muted">Date: <?= e($date) ?></p>

                <?php if (!$students): ?>
                    <div class="empty-state">
                        Is class/section mein student nahi mila.
                        Pehle Students module mein student add karein.
                    </div>
                <?php else: ?>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                        <input type="hidden" name="class_name" value="<?= e($className) ?>">
                        <input type="hidden" name="section" value="<?= e($section) ?>">
                        <input type="hidden" name="date" value="<?= e($date) ?>">

                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Admission No.</th>
                                        <th>Student Name</th>
                                        <th>Attendance Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $student): ?>
                                        <?php
                                        $currentStatus = $student['status'] ?: 'Present';
                                        ?>
                                        <tr>
                                            <td><?= e($student['admission_no']) ?></td>
                                            <td><?= e($student['first_name'] . ' ' . $student['last_name']) ?></td>
                                            <td>
                                                <select name="status[<?= (int) $student['id'] ?>]">
                                                    <?php foreach (['Present', 'Absent', 'Late'] as $status): ?>
                                                        <option value="<?= e($status) ?>"
                                                            <?= $currentStatus === $status ? 'selected' : '' ?>>
                                                            <?= e($status) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="form-actions">
                            <button class="button button-primary" type="submit">
                                Save Attendance
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <p class="back-link"><a href="../dashboard.php">← Dashboard par wapas jaayein</a></p>
    </main>
</body>
</html>