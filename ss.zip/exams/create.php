<?php
require __DIR__ . '/../config/auth.php';

$classes = $pdo->query(
    'SELECT DISTINCT class_name FROM students ORDER BY class_name'
)->fetchAll(PDO::FETCH_COLUMN);

$data = [
    'exam_name' => '',
    'class_name' => '',
    'section' => '',
    'subject' => '',
    'exam_date' => '',
    'max_marks' => '100',
];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    foreach (array_keys($data) as $field) {
        $data[$field] = trim($_POST[$field] ?? '');
    }

    $maxMarks = filter_var($data['max_marks'], FILTER_VALIDATE_FLOAT);

    $validDate = true;
    if ($data['exam_date'] !== '') {
        $dateObject = DateTime::createFromFormat('Y-m-d', $data['exam_date']);
        $validDate = $dateObject && $dateObject->format('Y-m-d') === $data['exam_date'];
    }

    if (
        $data['exam_name'] === '' ||
        $data['class_name'] === '' ||
        $data['subject'] === ''
    ) {
        $error = 'Exam name, class aur subject zaroori hain.';
    } elseif ($maxMarks === false || $maxMarks <= 0) {
        $error = 'Maximum marks zero se zyada hone chahiye.';
    } elseif (!$validDate) {
        $error = 'Exam date valid nahi hai.';
    } else {
        $classStmt = $pdo->prepare(
            'SELECT COUNT(*) FROM students WHERE class_name = ?'
        );
        $classStmt->execute([$data['class_name']]);

        if ((int) $classStmt->fetchColumn() === 0) {
            $error = 'Is class mein koi student nahi mila. Pehle student records add karein.';
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO exams
                    (exam_name, class_name, section, subject, exam_date, max_marks)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );

            $stmt->execute([
                $data['exam_name'],
                $data['class_name'],
                $data['section'] ?: null,
                $data['subject'],
                $data['exam_date'] ?: null,
                $maxMarks
            ]);

            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Exam — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <a class="button button-outline" href="index.php">Exams list</a>
    </header>

    <main class="container form-container">
        <section class="form-card">
            <h1>Create Exam</h1>
            <p class="muted">Exam ki details fill karein.</p>

            <?php if ($error): ?>
                <div class="alert"><?= e($error) ?></div>
            <?php endif; ?>

            <?php if (!$classes): ?>
                <div class="alert">Pehle Students module mein student add karein.</div>
            <?php else: ?>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                    <div class="form-grid">
                        <div>
                            <label for="exam_name">Exam Name *</label>
                            <input
                                id="exam_name"
                                name="exam_name"
                                placeholder="Jaise: Mid Term"
                                required
                                value="<?= e($data['exam_name']) ?>"
                            >
                        </div>

                        <div>
                            <label for="class_name">Class *</label>
                            <select id="class_name" name="class_name" required>
                                <option value="">Class select karein</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= e($class) ?>"
                                        <?= $data['class_name'] === $class ? 'selected' : '' ?>>
                                        <?= e($class) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label for="section">Section</label>
                            <input
                                id="section"
                                name="section"
                                placeholder="Jaise: A; bina section ke khaali chhodein"
                                value="<?= e($data['section']) ?>"
                            >
                        </div>

                        <div>
                            <label for="subject">Subject *</label>
                            <input
                                id="subject"
                                name="subject"
                                placeholder="Jaise: Mathematics"
                                required
                                value="<?= e($data['subject']) ?>"
                            >
                        </div>

                        <div>
                            <label for="exam_date">Exam Date</label>
                            <input
                                id="exam_date"
                                type="date"
                                name="exam_date"
                                value="<?= e($data['exam_date']) ?>"
                            >
                        </div>

                        <div>
                            <label for="max_marks">Maximum Marks *</label>
                            <input
                                id="max_marks"
                                type="number"
                                name="max_marks"
                                min="0.01"
                                step="0.01"
                                required
                                value="<?= e($data['max_marks']) ?>"
                            >
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="button button-primary" type="submit">Create Exam</button>
                        <a class="button button-outline" href="index.php">Cancel</a>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>