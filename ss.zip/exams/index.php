<?php
require __DIR__ . '/../config/auth.php';

$exams = $pdo->query(
    'SELECT
        e.*,
        (
            SELECT COUNT(*)
            FROM students s
            WHERE s.class_name = e.class_name
              AND COALESCE(s.section, "") = COALESCE(e.section, "")
        ) AS student_count,
        (
            SELECT COUNT(*)
            FROM exam_results r
            JOIN students s ON s.id = r.student_id
            WHERE r.exam_id = e.id
              AND s.class_name = e.class_name
              AND COALESCE(s.section, "") = COALESCE(e.section, "")
        ) AS result_count
     FROM exams e
     ORDER BY e.exam_date DESC, e.id DESC'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exams — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <div class="user-area">
            <span><?= e($_SESSION['name']) ?></span>
            <a class="button button-outline" href="../logout.php">Logout</a>
        </div>
    </header>

    <main class="container">
        <div class="page-heading">
            <div>
                <p class="eyebrow">SCHOOL MANAGEMENT</p>
                <h1>Exams & Results</h1>
                <p class="muted">Exams banayein aur students ke marks manage karein.</p>
            </div>

            <a class="button button-primary" href="create.php">+ Create Exam</a>
        </div>

        <section class="table-card">
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Exam</th>
                            <th>Class</th>
                            <th>Subject</th>
                            <th>Exam Date</th>
                            <th>Max Marks</th>
                            <th>Results Entered</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$exams): ?>
                            <tr>
                                <td colspan="7" class="empty-state">Abhi koi exam create nahi hua.</td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($exams as $exam): ?>
                            <tr>
                                <td><?= e($exam['exam_name']) ?></td>
                                <td>
                                    <?= e($exam['class_name']) ?>
                                    <?= $exam['section'] ? ' - ' . e($exam['section']) : '' ?>
                                </td>
                                <td><?= e($exam['subject']) ?></td>
                                <td><?= e($exam['exam_date'] ?: '—') ?></td>
                                <td><?= e($exam['max_marks']) ?></td>
                                <td>
                                    <?= (int) $exam['result_count'] ?>
                                    / <?= (int) $exam['student_count'] ?>
                                </td>
                                <td>
                                    <a
                                        class="button button-outline button-small"
                                        href="marks.php?id=<?= (int) $exam['id'] ?>"
                                    >Enter Marks</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <p class="back-link"><a href="../dashboard.php">← Dashboard par wapas jaayein</a></p>
    </main>
</body>
</html>