<?php
$moduleType = 'library';
require __DIR__ . '/../config/module_manager.php';