<?php
$moduleType = 'timetable';
require __DIR__ . '/../config/module_manager.php';