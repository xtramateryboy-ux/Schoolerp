<?php
$moduleType = 'homework';
require __DIR__ . '/../config/module_manager.php';