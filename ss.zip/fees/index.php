<?php
require __DIR__ . '/../config/auth.php';

$stmt = $pdo->query(
    'SELECT
        i.id,
        i.fee_title,
        i.amount,
        i.due_date,
        i.academic_year,
        i.created_at,
        s.admission_no,
        s.first_name,
        s.last_name,
        COALESCE(SUM(p.amount), 0) AS paid_amount
     FROM fee_invoices i
     JOIN students s ON s.id = i.student_id
     LEFT JOIN fee_payments p ON p.invoice_id = i.id
     GROUP BY i.id, s.id
     ORDER BY i.created_at DESC'
);

$invoices = $stmt->fetchAll();

$totalBilled = 0;
$totalPaid = 0;

foreach ($invoices as $invoice) {
    $totalBilled += (float) $invoice['amount'];
    $totalPaid += (float) $invoice['paid_amount'];
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fees — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <div class="user-area">
            <span><?= e($_SESSION['name']) ?></span>
            <a class="button button-outline" href="../logout.php">Logout</a>
        </div>
    </header>

    <main class="container">
        <div class="page-heading">
            <div>
                <p class="eyebrow">SCHOOL MANAGEMENT</p>
                <h1>Fees</h1>
                <p class="muted">Fee invoices aur received payments manage karein.</p>
            </div>
            <a class="button button-primary" href="create.php">+ Create Fee Invoice</a>
        </div>

        <section class="fee-summary">
            <div class="summary-card">
                <span>Total Billed</span>
                <strong>₹<?= number_format($totalBilled, 2) ?></strong>
            </div>
            <div class="summary-card">
                <span>Total Collected</span>
                <strong>₹<?= number_format($totalPaid, 2) ?></strong>
            </div>
            <div class="summary-card">
                <span>Outstanding</span>
                <strong>₹<?= number_format($totalBilled - $totalPaid, 2) ?></strong>
            </div>
        </section>

        <section class="table-card">
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Fee</th>
                            <th>Amount</th>
                            <th>Paid</th>
                            <th>Balance</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$invoices): ?>
                            <tr>
                                <td colspan="8" class="empty-state">Abhi koi fee invoice nahi hai.</td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($invoices as $invoice): ?>
                            <?php
                            $amount = (float) $invoice['amount'];
                            $paid = (float) $invoice['paid_amount'];
                            $balance = max(0, $amount - $paid);

                            if ($balance <= 0) {
                                $status = 'Paid';
                            } elseif ($paid > 0) {
                                $status = 'Partial';
                            } else {
                                $status = 'Unpaid';
                            }
                            ?>
                            <tr>
                                <td>
                                    <?= e($invoice['first_name'] . ' ' . $invoice['last_name']) ?>
                                    <small class="table-subtext">
                                        <?= e($invoice['admission_no']) ?>
                                    </small>
                                </td>
                                <td>
                                    <?= e($invoice['fee_title']) ?>
                                    <?php if ($invoice['academic_year']): ?>
                                        <small class="table-subtext">
                                            <?= e($invoice['academic_year']) ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td>₹<?= number_format($amount, 2) ?></td>
                                <td>₹<?= number_format($paid, 2) ?></td>
                                <td>₹<?= number_format($balance, 2) ?></td>
                                <td><?= e($invoice['due_date'] ?: '—') ?></td>
                                <td>
                                    <span class="fee-status status-<?= strtolower($status) ?>">
                                        <?= e($status) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($balance > 0): ?>
                                        <a
                                            class="button button-outline button-small"
                                            href="pay.php?id=<?= (int) $invoice['id'] ?>"
                                        >Record Payment</a>
                                    <?php else: ?>
                                        <span class="muted">Complete</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <p class="back-link"><a href="../dashboard.php">← Dashboard par wapas jaayein</a></p>
    </main>
</body>
</html>