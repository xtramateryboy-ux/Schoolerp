<?php
require __DIR__ . '/../config/auth.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$isEdit = $id !== false && $id !== null;

$student = [
    'admission_no' => '',
    'first_name' => '',
    'last_name' => '',
    'gender' => 'Other',
    'date_of_birth' => '',
    'class_name' => '',
    'section' => '',
    'parent_name' => '',
    'parent_phone' => '',
    'address' => '',
];

if ($isEdit) {
    $stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
    $stmt->execute([$id]);
    $existingStudent = $stmt->fetch();

    if (!$existingStudent) {
        http_response_code(404);
        exit('Student record nahi mila.');
    }

    $student = $existingStudent;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $student['admission_no'] = trim($_POST['admission_no'] ?? '');
    $student['first_name'] = trim($_POST['first_name'] ?? '');
    $student['last_name'] = trim($_POST['last_name'] ?? '');
    $student['gender'] = $_POST['gender'] ?? 'Other';
    $student['date_of_birth'] = $_POST['date_of_birth'] ?? '';
    $student['class_name'] = trim($_POST['class_name'] ?? '');
    $student['section'] = trim($_POST['section'] ?? '');
    $student['parent_name'] = trim($_POST['parent_name'] ?? '');
    $student['parent_phone'] = trim($_POST['parent_phone'] ?? '');
    $student['address'] = trim($_POST['address'] ?? '');

    $allowedGenders = ['Male', 'Female', 'Other'];

    if (
        $student['admission_no'] === '' ||
        $student['first_name'] === '' ||
        $student['last_name'] === '' ||
        $student['class_name'] === ''
    ) {
        $error = 'Admission number, first name, last name aur class zaroori hain.';
    } elseif (!in_array($student['gender'], $allowedGenders, true)) {
        $error = 'Gender selection valid nahi hai.';
    } else {
        try {
            if ($isEdit) {
                $stmt = $pdo->prepare(
                    'UPDATE students SET
                        admission_no = ?,
                        first_name = ?,
                        last_name = ?,
                        gender = ?,
                        date_of_birth = ?,
                        class_name = ?,
                        section = ?,
                        parent_name = ?,
                        parent_phone = ?,
                        address = ?
                     WHERE id = ?'
                );

                $stmt->execute([
                    $student['admission_no'],
                    $student['first_name'],
                    $student['last_name'],
                    $student['gender'],
                    $student['date_of_birth'] ?: null,
                    $student['class_name'],
                    $student['section'] ?: null,
                    $student['parent_name'] ?: null,
                    $student['parent_phone'] ?: null,
                    $student['address'] ?: null,
                    $id
                ]);
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO students
                        (admission_no, first_name, last_name, gender, date_of_birth,
                         class_name, section, parent_name, parent_phone, address)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );

                $stmt->execute([
                    $student['admission_no'],
                    $student['first_name'],
                    $student['last_name'],
                    $student['gender'],
                    $student['date_of_birth'] ?: null,
                    $student['class_name'],
                    $student['section'] ?: null,
                    $student['parent_name'] ?: null,
                    $student['parent_phone'] ?: null,
                    $student['address'] ?: null
                ]);
            }

            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = 'Yeh admission number pehle se use ho raha hai.';
            } else {
                $error = 'Student save nahi ho saka. Dobara try karein.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $isEdit ? 'Edit' : 'Add' ?> Student — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <a class="button button-outline" href="index.php">Students list</a>
    </header>

    <main class="container form-container">
        <section class="form-card">
            <h1><?= $isEdit ? 'Edit Student' : 'Add Student' ?></h1>
            <p class="muted">Student ki details fill karein.</p>

            <?php if ($error): ?>
                <div class="alert"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <div class="form-grid">
                    <div>
                        <label for="admission_no">Admission Number *</label>
                        <input id="admission_no" name="admission_no" required
                               value="<?= e($student['admission_no']) ?>">
                    </div>

                    <div>
                        <label for="class_name">Class *</label>
                        <input id="class_name" name="class_name" required
                               placeholder="Jaise: Class 5"
                               value="<?= e($student['class_name']) ?>">
                    </div>

                    <div>
                        <label for="first_name">First Name *</label>
                        <input id="first_name" name="first_name" required
                               value="<?= e($student['first_name']) ?>">
                    </div>

                    <div>
                        <label for="last_name">Last Name *</label>
                        <input id="last_name" name="last_name" required
                               value="<?= e($student['last_name']) ?>">
                    </div>

                    <div>
                        <label for="section">Section</label>
                        <input id="section" name="section"
                               placeholder="Jaise: A"
                               value="<?= e($student['section']) ?>">
                    </div>

                    <div>
                        <label for="gender">Gender</label>
                        <select id="gender" name="gender">
                            <?php foreach (['Male', 'Female', 'Other'] as $gender): ?>
                                <option value="<?= e($gender) ?>"
                                    <?= $student['gender'] === $gender ? 'selected' : '' ?>>
                                    <?= e($gender) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="date_of_birth">Date of Birth</label>
                        <input id="date_of_birth" type="date" name="date_of_birth"
                               value="<?= e($student['date_of_birth']) ?>">
                    </div>

                    <div>
                        <label for="parent_name">Parent / Guardian Name</label>
                        <input id="parent_name" name="parent_name"
                               value="<?= e($student['parent_name']) ?>">
                    </div>

                    <div>
                        <label for="parent_phone">Parent Phone</label>
                        <input id="parent_phone" name="parent_phone" type="tel"
                               value="<?= e($student['parent_phone']) ?>">
                    </div>

                    <div class="form-full">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" rows="3"><?= e($student['address']) ?></textarea>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="button button-primary" type="submit">
                        <?= $isEdit ? 'Update Student' : 'Save Student' ?>
                    </button>
                    <a class="button button-outline" href="index.php">Cancel</a>
                </div>
            </form>
        </section>
    </main>
</body>
</html>

<?php
require __DIR__ . '/../config/auth.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$isEdit = $id !== false && $id !== null;

$student = [
    'admission_no' => '',
    'first_name' => '',
    'last_name' => '',
    'gender' => 'Other',
    'date_of_birth' => '',
    'class_name' => '',
    'section' => '',
    'parent_name' => '',
    'parent_phone' => '',
    'address' => '',
];

if ($isEdit) {
    $stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
    $stmt->execute([$id]);
    $existingStudent = $stmt->fetch();

    if (!$existingStudent) {
        http_response_code(404);
        exit('Student record nahi mila.');
    }

    $student = $existingStudent;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $student['admission_no'] = trim($_POST['admission_no'] ?? '');
    $student['first_name'] = trim($_POST['first_name'] ?? '');
    $student['last_name'] = trim($_POST['last_name'] ?? '');
    $student['gender'] = $_POST['gender'] ?? 'Other';
    $student['date_of_birth'] = $_POST['date_of_birth'] ?? '';
    $student['class_name'] = trim($_POST['class_name'] ?? '');
    $student['section'] = trim($_POST['section'] ?? '');
    $student['parent_name'] = trim($_POST['parent_name'] ?? '');
    $student['parent_phone'] = trim($_POST['parent_phone'] ?? '');
    $student['address'] = trim($_POST['address'] ?? '');

    $allowedGenders = ['Male', 'Female', 'Other'];

    if (
        $student['admission_no'] === '' ||
        $student['first_name'] === '' ||
        $student['last_name'] === '' ||
        $student['class_name'] === ''
    ) {
        $error = 'Admission number, first name, last name aur class zaroori hain.';
    } elseif (!in_array($student['gender'], $allowedGenders, true)) {
        $error = 'Gender selection valid nahi hai.';
    } else {
        try {
            if ($isEdit) {
                $stmt = $pdo->prepare(
                    'UPDATE students SET
                        admission_no = ?,
                        first_name = ?,
                        last_name = ?,
                        gender = ?,
                        date_of_birth = ?,
                        class_name = ?,
                        section = ?,
                        parent_name = ?,
                        parent_phone = ?,
                        address = ?
                     WHERE id = ?'
                );

                $stmt->execute([
                    $student['admission_no'],
                    $student['first_name'],
                    $student['last_name'],
                    $student['gender'],
                    $student['date_of_birth'] ?: null,
                    $student['class_name'],
                    $student['section'] ?: null,
                    $student['parent_name'] ?: null,
                    $student['parent_phone'] ?: null,
                    $student['address'] ?: null,
                    $id
                ]);
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO students
                        (admission_no, first_name, last_name, gender, date_of_birth,
                         class_name, section, parent_name, parent_phone, address)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );

                $stmt->execute([
                    $student['admission_no'],
                    $student['first_name'],
                    $student['last_name'],
                    $student['gender'],
                    $student['date_of_birth'] ?: null,
                    $student['class_name'],
                    $student['section'] ?: null,
                    $student['parent_name'] ?: null,
                    $student['parent_phone'] ?: null,
                    $student['address'] ?: null
                ]);
            }

            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = 'Yeh admission number pehle se use ho raha hai.';
            } else {
                $error = 'Student save nahi ho saka. Dobara try karein.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $isEdit ? 'Edit' : 'Add' ?> Student — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <a class="button button-outline" href="index.php">Students list</a>
    </header>

    <main class="container form-container">
        <section class="form-card">
            <h1><?= $isEdit ? 'Edit Student' : 'Add Student' ?></h1>
            <p class="muted">Student ki details fill karein.</p>

            <?php if ($error): ?>
                <div class="alert"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <div class="form-grid">
                    <div>
                        <label for="admission_no">Admission Number *</label>
                        <input id="admission_no" name="admission_no" required
                               value="<?= e($student['admission_no']) ?>">
                    </div>

                    <div>
                        <label for="class_name">Class *</label>
                        <input id="class_name" name="class_name" required
                               placeholder="Jaise: Class 5"
                               value="<?= e($student['class_name']) ?>">
                    </div>

                    <div>
                        <label for="first_name">First Name *</label>
                        <input id="first_name" name="first_name" required
                               value="<?= e($student['first_name']) ?>">
                    </div>

                    <div>
                        <label for="last_name">Last Name *</label>
                        <input id="last_name" name="last_name" required
                               value="<?= e($student['last_name']) ?>">
                    </div>

                    <div>
                        <label for="section">Section</label>
                        <input id="section" name="section"
                               placeholder="Jaise: A"
                               value="<?= e($student['section']) ?>">
                    </div>

                    <div>
                        <label for="gender">Gender</label>
                        <select id="gender" name="gender">
                            <?php foreach (['Male', 'Female', 'Other'] as $gender): ?>
                                <option value="<?= e($gender) ?>"
                                    <?= $student['gender'] === $gender ? 'selected' : '' ?>>
                                    <?= e($gender) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="date_of_birth">Date of Birth</label>
                        <input id="date_of_birth" type="date" name="date_of_birth"
                               value="<?= e($student['date_of_birth']) ?>">
                    </div>

                    <div>
                        <label for="parent_name">Parent / Guardian Name</label>
                        <input id="parent_name" name="parent_name"
                               value="<?= e($student['parent_name']) ?>">
                    </div>

                    <div>
                        <label for="parent_phone">Parent Phone</label>
                        <input id="parent_phone" name="parent_phone" type="tel"
                               value="<?= e($student['parent_phone']) ?>">
                    </div>

                    <div class="form-full">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" rows="3"><?= e($student['address']) ?></textarea>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="button button-primary" type="submit">
                        <?= $isEdit ? 'Update Student' : 'Save Student' ?>
                    </button>
                    <a class="button button-outline" href="index.php">Cancel</a>
                </div>
            </form>
        </section>
    </main>
</body>
</html>