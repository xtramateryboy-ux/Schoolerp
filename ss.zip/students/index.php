<?php
require __DIR__ . '/../config/auth.php';

$search = trim($_GET['search'] ?? '');

if ($search !== '') {
    $stmt = $pdo->prepare(
        'SELECT * FROM students
         WHERE admission_no LIKE ?
            OR first_name LIKE ?
            OR last_name LIKE ?
            OR class_name LIKE ?
         ORDER BY id DESC'
    );

    $like = '%' . $search . '%';
    $stmt->execute([$like, $like, $like, $like]);
} else {
    $stmt = $pdo->query('SELECT * FROM students ORDER BY id DESC');
}

$students = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <div class="user-area">
            <span><?= e($_SESSION['name']) ?></span>
            <a class="button button-outline" href="../logout.php">Logout</a>
        </div>
    </header>

    <main class="container">
        <div class="page-heading">
            <div>
                <p class="eyebrow">SCHOOL MANAGEMENT</p>
                <h1>Students</h1>
                <p class="muted">Student records add aur manage karein.</p>
            </div>

            <a class="button button-primary" href="form.php">+ Add Student</a>
        </div>

        <section class="table-card">
            <form class="search-form" method="GET">
                <input
                    type="search"
                    name="search"
                    placeholder="Name, admission no. ya class se search karein"
                    value="<?= e($search) ?>"
                >
                <button class="button button-primary" type="submit">Search</button>

                <?php if ($search !== ''): ?>
                    <a class="button button-outline" href="index.php">Clear</a>
                <?php endif; ?>
            </form>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Admission No.</th>
                            <th>Student Name</th>
                            <th>Class</th>
                            <th>Parent / Guardian</th>
                            <th>Phone</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$students): ?>
                            <tr>
                                <td colspan="6" class="empty-state">
                                    Koi student record nahi mila.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?= e($student['admission_no']) ?></td>
                                <td><?= e($student['first_name'] . ' ' . $student['last_name']) ?></td>
                                <td>
                                    <?= e($student['class_name']) ?>
                                    <?= $student['section'] ? ' - ' . e($student['section']) : '' ?>
                                </td>
                                <td><?= e($student['parent_name'] ?: '—') ?></td>
                                <td><?= e($student['parent_phone'] ?: '—') ?></td>
                                <td class="actions">
                                    <a
                                        class="button button-outline button-small"
                                        href="form.php?id=<?= (int) $student['id'] ?>"
                                    >Edit</a>

                                    <form
                                        method="POST"
                                        action="delete.php"
                                        onsubmit="return confirm('Kya aap is student ko delete karna chahte hain?');"
                                    >
                                        <input type="hidden" name="id" value="<?= (int) $student['id'] ?>">
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($_SESSION['csrf_token']) ?>"
                                        >
                                        <button class="button button-danger button-small" type="submit">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <p class="back-link"><a href="../dashboard.php">← Dashboard par wapas jaayein</a></p>
    </main>
</body>
</html>