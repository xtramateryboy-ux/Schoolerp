<?php
require __DIR__ . '/../config/auth.php';

$search = trim($_GET['search'] ?? '');

if ($search !== '') {
    $like = '%' . $search . '%';

    $stmt = $pdo->prepare(
        'SELECT * FROM teachers
         WHERE employee_no LIKE ?
            OR first_name LIKE ?
            OR last_name LIKE ?
            OR email LIKE ?
            OR subject LIKE ?
         ORDER BY id DESC'
    );

    $stmt->execute([$like, $like, $like, $like, $like]);
} else {
    $stmt = $pdo->query('SELECT * FROM teachers ORDER BY id DESC');
}

$teachers = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teachers — School ERP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header class="topbar">
        <a class="logo" href="../dashboard.php">School ERP</a>
        <div class="user-area">
            <span><?= e($_SESSION['name']) ?></span>
            <a class="button button-outline" href="../logout.php">Logout</a>
        </div>
    </header>

    <main class="container">
        <div class="page-heading">
            <div>
                <p class="eyebrow">SCHOOL MANAGEMENT</p>
                <h1>Teachers</h1>
                <p class="muted">Teacher records add aur manage karein.</p>
            </div>
            <a class="button button-primary" href="form.php">+ Add Teacher</a>
        </div>

        <section class="table-card">
            <form class="search-form" method="GET">
                <input
                    type="search"
                    name="search"
                    placeholder="Name, employee no., email ya subject se search karein"
                    value="<?= e($search) ?>"
                >
                <button class="button button-primary" type="submit">Search</button>

                <?php if ($search !== ''): ?>
                    <a class="button button-outline" href="index.php">Clear</a>
                <?php endif; ?>
            </form>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Employee No.</th>
                            <th>Teacher Name</th>
                            <th>Subject</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$teachers): ?>
                            <tr>
                                <td colspan="6" class="empty-state">
                                    Koi teacher record nahi mila.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($teachers as $teacher): ?>
                            <tr>
                                <td><?= e($teacher['employee_no']) ?></td>
                                <td><?= e($teacher['first_name'] . ' ' . $teacher['last_name']) ?></td>
                                <td><?= e($teacher['subject'] ?: '—') ?></td>
                                <td><?= e($teacher['email']) ?></td>
                                <td><?= e($teacher['phone'] ?: '—') ?></td>
                                <td class="actions">
                                    <a
                                        class="button button-outline button-small"
                                        href="form.php?id=<?= (int) $teacher['id'] ?>"
                                    >Edit</a>

                                    <form
                                        method="POST"
                                        action="delete.php"
                                        onsubmit="return confirm('Kya aap is teacher ko delete karna chahte hain?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $teacher['id'] ?>"
                                        >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($_SESSION['csrf_token']) ?>"
                                        >
                                        <button class="button button-danger button-small" type="submit">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <p class="back-link"><a href="../dashboard.php">← Dashboard par wapas jaayein</a></p>
    </main>
</body>
</html>